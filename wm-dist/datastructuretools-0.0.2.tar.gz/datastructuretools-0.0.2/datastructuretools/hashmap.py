# coding: utf-8

import pickle as pickle
from systemtools.basics import *
from systemtools.logger import *
from systemtools.location import *
from systemtools.file import *
import os
import gzip
import sys

def objectSizeMo(obj):
    size = sys.getsizeof(obj)
    size /= 1024.0
    size /= 1024.0
    return size

class SerializableDict():
    """
        With processingFunct this class works the same as datastructuretools.basics.CacheDict
    """
    def __init__ \
    (
        self,
        dirPath,
        name,
        compresslevel=0,
        logger=None,
        verbose=False,
        readAndAddOnly=False,
        processingFunct=None,
        cleanMaxSizeMoReadModifiedOlder=None, # cleanMaxSizeMoReadModifiedOlder
        cleanMaxValueCountReadModifiedOlder=None, # cleanMaxValueCountReadModifiedOlder
        cleanNotReadOrModifiedSinceNDays=None, # cleanNotReadOrModifiedSinceNDays
        cleanNotReadOrModifiedSinceNSeconds=None, # cleanNotReadOrModifiedSinceNSeconds
        cleanEachNAction=500,
        serializeEachNAction=500,
    ):
        self.cleanMaxSizeMoReadModifiedOlder = cleanMaxSizeMoReadModifiedOlder
        self.data = dict()
        self.processingFunct = processingFunct
        self.readAndAddOnly = readAndAddOnly
        self.actionCount = 0
        self.serializeEachNAction = serializeEachNAction
        self.cleanEachNAction = cleanEachNAction
        self.cleanMaxValueCountReadModifiedOlder = cleanMaxValueCountReadModifiedOlder
        self.cleanNotReadOrModifiedSinceNDays = cleanNotReadOrModifiedSinceNDays
        if cleanNotReadOrModifiedSinceNSeconds is not None:
            self.cleanNotReadOrModifiedSinceNDays = cleanNotReadOrModifiedSinceNSeconds / 3600 / 24
        self.logger = logger
        self.verbose = verbose
        self.filePath = dirPath + "/" + name + ".pickle.zip"
        self.compresslevel = compresslevel
        self.load()
        self.clean()

    def __getitem__(self, index):
        return self.get(index)
    def __setitem__(self, index, value):
        self.add(index, value)
    def __contains__(self, key):
        return self.hasKey(key)
    def __len__(self):
        return self.size()
    def __del__(self):
        return self.reset()


    def save(self, *argv, **kwargs):
        self.serialize(*argv, **kwargs)
    def serialize(self):
        f = None
        if self.compresslevel > 0:
            f = gzip.GzipFile(self.filePath, 'wb', compresslevel=self.compresslevel)
        else:
            f = open(self.filePath, 'wb')
        try:
            pickle.dump(self.data, f, pickle.HIGHEST_PROTOCOL)
        finally:
            f.close()


    def add(self, key, value):
        self.gotAnAction()
        if self.hasKey(key):
            if not self.readAndAddOnly:
                self.data[key]["modified"] = time.time()
                self.data[key]["modifiedCount"] += 1
                self.data[key]["value"] = value
        else:
            value = {"value": value}
            value["modified"] = time.time()
            value["modifiedCount"] = 0
            value["created"] = time.time()
            value["read"] = time.time()
            value["readCount"] = 0
            self.data[key] = value

    def conditionalSerialize(self):
        if self.serializeEachNAction is not None and self.serializeEachNAction > 0:
            if self.actionCount % self.serializeEachNAction == 0:
                self.serialize()

    def gotAnAction(self):
        self.actionCount += 1
        self.conditionalSerialize()
        self.conditionalClean()

    def get(self, key):
        self.gotAnAction()
        if self.hasKey(key):
            self.data[key]["read"] = time.time()
            self.data[key]["readCount"] += 1
            return self.data[key]["value"]
        elif self.processingFunct is not None:
            self.add(key, self.processingFunct(key))
            return self.get(key)
        else:
            return None

    def hasKey(self, key):
        return key in self.data

    def load(self):
        if (len(sortedGlob(self.filePath)) > 0):
            log("Loading " + self.filePath + " from the disk", self)
            f = None
            if self.compresslevel > 0:
                f = gzip.GzipFile(self.filePath, 'rb', compresslevel=self.compresslevel)
            else:
                f = open(self.filePath, 'rb')
            try:
                self.data = pickle.load(f)
            finally:
                f.close()

    def close(self):
        self.clean()
        self.serialize()

    def removeFile(self):
        removeIfExists(self.filePath)

    def reset(self):
        self.removeFile()
        self.data = dict()


    def conditionalClean(self):
        if self.cleanEachNAction is not None and self.cleanEachNAction > 0:
            if self.actionCount % self.cleanEachNAction == 0:
                self.clean()

    def getToDeleteOlder(self, toDeleteCount):
        sortedIndex = []
        for key, value in self.data.items():
            currentModified = value["modified"]
            currentRead = value["read"]
#             print("key=" + str(key))
#             print("currentModified=" + str(currentModified))
#             print("currentRead=" + str(currentRead))
            toTake = currentModified
            if currentRead > currentModified:
                toTake = currentRead
            sortedIndex.append((key, toTake))
        sortedIndex = sortBy(sortedIndex, desc=False, index=1)
        toDelete = set()
        for i in range(toDeleteCount):
            toDelete.add(sortedIndex[i][0])
#         exit()
        return toDelete

    def dataSizeMo(self):
        """
            Warning getsizeof doesn't give real size of a dict because it can keep a huge size for performance issue, so we have to calculate the data size on each element:
            https://stackoverflow.com/questions/11129546/python-sys-getsizeof-reports-same-size-after-items-removed-from-list-dict
        """
        total = 0
        for key, value in self.data.items():
            total += objectSizeMo(key)
            total += objectSizeMo(value)
        return total

    def clean(self):
        cleanedCount = 0
        if self.cleanNotReadOrModifiedSinceNDays is not None and self.cleanNotReadOrModifiedSinceNDays > 0:
            toDelete = set()
            cleanNotReadOrModifiedSinceNSeconds = self.cleanNotReadOrModifiedSinceNDays * 24 * 3600
            for key, current in self.data.items():
                modifiedInterval = time.time() - current["modified"]
                readInterval = time.time() - current["read"]
                if modifiedInterval > cleanNotReadOrModifiedSinceNSeconds or readInterval > cleanNotReadOrModifiedSinceNSeconds:
                    toDelete.add(key)
            for current in toDelete:
                del self.data[current]
            cleanedCount += len(toDelete)
        if self.cleanMaxValueCountReadModifiedOlder is not None and \
        self.cleanMaxValueCountReadModifiedOlder > 0 and \
        self.size() > self.cleanMaxValueCountReadModifiedOlder:
            toDeleteCount = self.size() - self.cleanMaxValueCountReadModifiedOlder
            toDelete = self.getToDeleteOlder(toDeleteCount)
            cleanedCount += len(toDelete)
            for current in toDelete:
                del self.data[current]
        if self.cleanMaxSizeMoReadModifiedOlder is not None and \
        self.cleanMaxSizeMoReadModifiedOlder > 0:
            while self.dataSizeMo() > self.cleanMaxSizeMoReadModifiedOlder:
                toDeleteCount = self.size() // 20 # We delete 5%
                toDelete = self.getToDeleteOlder(toDeleteCount)
                cleanedCount += len(toDelete)
                for current in toDelete:
                    del self.data[current]
        # Here you can other "clean condition"
        # ...
        if cleanedCount > 0:
            log(str(cleanedCount) + " items was cleaned from " + self.filePath, self)

    def size(self):
        return len(self.data)


class SerializableHashMap():
    # class Value(): # Todo date history, object, max number (limit)...

    def __init__(self, filePath, compresslevel=0):
        self.data = dict()
        self.filePath = filePath
        self.compresslevel = compresslevel
        self.load()

    def serialize(self):
        f = None
        if self.compresslevel > 0:
            f = gzip.GzipFile(self.filePath, 'w', compresslevel=self.compresslevel)
        else:
            f = open(self.filePath, 'w')
        try:
            pickle.dump(self.data, f, pickle.HIGHEST_PROTOCOL)
        finally:
            f.close()

    def add(self, key, value):
        self.data[key] = value

    def getOne(self, *args, **kwargs):
        return self.get(*args, **kwargs)
    def get(self, key):
        if key in self:
            return self.data[key]
        else:
            return None

    def hasKey(self, *args, **kwargs):
        return self.has_key(*args, **kwargs)
    def has_key(self, key):
        return key in self.data

    def load(self):
        if (len(sortedGlob(self.filePath)) > 0):
            print("Loading " + self.filePath + " from the disk")
            f = None
            if self.compresslevel > 0:
                f = gzip.GzipFile(self.filePath, 'r', compresslevel=self.compresslevel)
            else:
                f = open(self.filePath, 'r')
            try:
                self.data = pickle.load(f)
            finally:
                f.close()

    def clean(self):
        if (len(sortedGlob(self.filePath)) > 0):
            os.remove(self.filePath)
        self.data = dict()

    def size(self):
        return len(self.data)


class SentencePair:
    def __init__(self, s1, s2):
        assert(isinstance(s1, str) or isinstance(s1, str))
        assert(isinstance(s2, str) or isinstance(s1, str))
        self.s1 = s1
        self.s2 = s2

    def __hash__(self):
        return (self.s1 + "\t" + self.s2).__hash__()

    def __eq__(self, other):
        return (self.s1 == other.s1) and (self.s2 == other.s2)

    def __str__(self):
        if isinstance(self.s1, str):
            return str(self.s1) + "\t" + str(self.s2)
        elif isinstance(self.s1, str):
            import unicodedata
            return unicodedata.normalize('NFKD', self.s1 + "\t" + self.s2).encode('ascii','ignore')
        else:
            return "Unknown object."


