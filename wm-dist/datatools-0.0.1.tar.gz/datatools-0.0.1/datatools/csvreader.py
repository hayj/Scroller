# coding: utf-8


import csv
    
# TODO inherit JsonReader with openFunct etc...
    
class CSVReader():
    def __init__(self, filePath, delimiter='\t', quotechar='|', strip=True, correctQuote=True):
        self.filePath = filePath
        self.delimiter = delimiter
        self.correctQuote = correctQuote
        self.strip = strip
        self.quotechar = quotechar
        self.reader = csv.reader(open(filePath, newline=''), delimiter=self.delimiter, quotechar=self.quotechar)

    def __iter__(self):
        cols = None
        for row in self.reader:
            if cols is None:
                cols = row
            else:
                theDict = {}
                for currentCol in cols:
                    theDict[currentCol] = None
                i = 0
                for i in range(len(row)):
                    if i < len(cols):
                        currentValue = row[i]
                        currentCol = cols[i]
                        if self.strip:
                            currentValue = currentValue.strip()
                        if self.correctQuote:
                            if len(currentValue) > 0 \
                            and currentValue[0] == '"' \
                            and currentValue[-1] == '"':
                                currentValue = currentValue[1:-1]
                        if currentValue == "":
                            currentValue = None
                        theDict[currentCol] = currentValue
                        i += 1
                thereIsAtLeastOneValue = False
                for key, value in theDict.items():
                    if value is not None:
                        thereIsAtLeastOneValue = True
                        break
                if thereIsAtLeastOneValue:
                    yield theDict
        

# class csvGene
#     spamReader = csv.reader(open('/home/hayj/Dashboard/Notes/Recherche/news-website-list/google-news-sources.csv', newline=''), delimiter='\t', quotechar='|')
#     for row in spamReader:
#         print(', '.join(row))
#         input()

if __name__ == '__main__':
    cr = CSVReader('/home/hayj/Dashboard/Notes/Recherche/news-website-list/list.csv')
    
    for current in cr:
        print(current)
        input()