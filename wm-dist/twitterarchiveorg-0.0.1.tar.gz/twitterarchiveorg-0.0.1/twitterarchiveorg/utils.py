# coding: utf-8

from datatools.url import *
from datatools.csvreader import *
from systemtools.basics import *
from systemtools.duration import *
from systemtools.file import *
from systemtools.logger import log, logInfo, logWarning, logWarning, logError, Logger
from systemtools.location import *
import random
import re
from databasetools.mongo import *
from twitterarchiveorg.urlgenerator import *
from collections import OrderedDict


def tweetToReadable(tweets):
    if not isinstance(tweets, list):
        tweets = [tweets]
    allTweets = []
    for tweet in tweets:
        result = OrderedDict()
        result["text"] = tweet["text"]
        result["user_id"] = tweet["user_id"]
        result["is_retweet"] = dictContains(tweet, "retweeted_status")
        if dictContains(tweet, "news_count"):
            result["news_count"] = tweet["news_count"]
        if dictContains(tweet, "extended_tweet"):
            if dictContains(tweet["extended_tweet"], "full_text"):
                result["ftxt"] = tweet["extended_tweet"]["full_text"]
        result["news"] = getNewsFromTweet(tweet)
        allTweets.append(result)
    if len(allTweets) == 1:
        return allTweets[0]
    else:
        return allTweets

    
if __name__ == "__main__":
    for tweet in JsonReader(sortedGlob("/home/hayj/Data/TwitterArchiveOrg/Converted2/*.bz2")):
        printLTS(tweetToReadable(tweet))
        break

# Voir fichier itemtest pour l'utilisation de cette 

