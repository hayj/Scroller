# coding: utf-8


from datatools.json import *
from systemtools.location import *
from twitterarchiveorg.linktest import *



if __name__ == '__main__':
    
    
    for current in JsonReader(sortedGlob("/home/hayj/Data/TwitterArchiveOrg/Test/Original/*/*/*/*/*.bz2")):
        print(toJsonString(current))
#         current["user"] = None
#         print(current["text"])
#         print(listToStr(current))
        input()
    
    exit()

    
    deleteCount = 0 # 18324
    jr = JsonReader(sortedGlob("/home/hayj/Data/TwitterArchiveOrg/Test/Original/*/*/*/*/*.bz2"))
    for current in jr:
#         if "delete" in current:
# #             print(listToStr(current))
#             deleteCount += 1
#     print(deleteCount)
        if "lang" in current and current["lang"] == "en":
            print(listToStr(current))
            input()
#             urls = extractURLs(current["text"])
# #             if "https://t.c…" in current["text"]:
# #             if "RT" in current["text"]:
# #             if "retweeted_status" in current:
#             if current["truncated"]:
#                 if urls is not None and len(urls) > 0:
#                      
#                     print(listToStr(current))
#                     print(current["text"])
#                     print(urls)
#     #                     print(convertTwitterURL(urls))
#     #                     if "entities" in current:
#     #                         print("entities: " + listToStr(current["entities"]))
#     #                     if "extended_entities" in current:
#     #                         print("extended_entities: " + listToStr(current["extended_entities"]))
#                     input()




