# coding: utf-8


from datatools.json import *
from systemtools.location import *
import urllib.request


def convertTwitterURL(urls):
    def convert(url):
        try:
            req = urllib.request.urlopen(url)
            return req.url
        except:
            return None
    if urls is None:
        return None
    if isinstance(urls, list):
        newUrls = []
        for currentUrl in urls:
            newUrls.append(convert(currentUrl))
        return newUrls
    else:
        return convert(urls)

def extractURLs(text):
    regex = re.compile("(http|ftp|https)://([\w_-]+(?:(?:\.[\w_-]+)+))([\w.,@?^=%&:/~+#-]*[\w@?^=%&/~+#-])?")
    result = regex.finditer(text)
    urls = []
    if result is not None:
        for urlFound in result:
            group0 = urlFound.group(0)
            urls.append(group0)
    return urls


# 1 faire une colonne avec tous les t.co 2. faire tous les liens et ajouter une colonne avec une liste de vrai liens 3 faire le scrapping
if __name__ == '__main__':
    
    jr = JsonReader(sortedGlob("/home/hayj/Data/TwitterArchiveOrg/Test/Converted/*.bz2"))


    'RT @CrowdFundGurus: Free Uber ride: click here for a free ride up to $20 using the promo code "JimV121" https://t.co/IQUVOqZPFf https://t.c…'
