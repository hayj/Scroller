# coding: utf-8


# Sur octods
# nn -o nohup-popularity.out pew in twitterarchiveorg-venv python /home/hayj/wm-dist-tmp/TwitterArchiveOrg/twitterarchiveorg/popularity.py

import sys
sys.path.append("/home/hayj/wm-dist-tmp/TwitterArchiveOrg")

from systemtools.hayj import *
from systemtools.basics import *
from systemtools.location import *
from systemtools.system import *
from systemtools.logger import *
from datatools.json import *
from databasetools.mongo import *
from twitterarchiveorg.itemhandler import *
from twitterarchiveorg import __version__
import pymongo


logger = Logger("popularity.log")
theConverted = "Converted3.3"
if isHostname("hjlat"):
    (user, password, host) = (None, None, None) # mongod-start
else:
    (user, password, host) = getMongoAuth("hayj", "datascience01")
taotweets = MongoCollection("taotweets",
                             theConverted.lower(),
                             version=__version__,
                             user=user, password=password, host=host,
                             indexNotUniqueOn=["user_id", "timestamp"],
                             giveTimestamp=False,
                             logger=logger)
taopopularity = MongoCollection("taopopularity",
                             theConverted.lower(),
                             version=__version__,
                             user=user, password=password, host=host,
                             logger=logger,
                             giveTimestamp=False,
                             indexOn=["item"],
                             indexNotUniqueOn=["count"])


taopopularity.resetCollection(security=isHostname("datasc"))

# Example :
# {
#     "item": url,
#     "count": 100,
#     "tweet_ids": [],
# }
count = 0
for current in taotweets.find():
    id = current["_id"]
    items = current["items"]
    for item in items:
        if taopopularity.has(item):
            # Update:
            taopopularity.updateOne({"item": item},
            {
                "$inc":
                {
                    "count": 1
                },
                "$push":
                {
                    "tweet_ids": id
                }
            })
        else:
            taopopularity.insert({"item": item, "tweet_ids": [id], "count": 1})
            count += 1
            log(count, logger)

taopopularity.show(sort=("count", pymongo.DESCENDING), limit=1)
taopopularity.show(sort=("count", pymongo.ASCENDING), limit=10)


