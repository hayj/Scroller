
# Execution:
# nn pew in webcrawler-venv python /home/hayj/wm-dist-tmp/WebCrawler/webcrawler/checkproxies.py

# Mise à jour sur hjlat et partout:
# rsync -avhu -e "ssh -p 2222" hayj@212.129.44.40:~/Data/Misc/crawling/proxies-failed.txt ~/Data/Misc/crawling/ && ~/Data/magic.sh

import sys, os; sys.path.append("/".join(os.path.abspath(__file__).split("/")[0:-2]))

from datatools.url import *
from systemtools.basics import *
from systemtools.duration import *
from systemtools.file import *
from systemtools.logger import log, logInfo, logWarning, logError, Logger
from systemtools.location import *
from systemtools.hayj import *
from systemtools.system import *
import sh
import random
import re
from threading import Thread, Lock, Semaphore, active_count
from webcrawler.crawler import *
from webcrawler.utils import *
from webcrawler.browser import *
from webcrawler.newsscraper import *
from queue import *
from databasetools.mongo import *
from databasetools.mongo import *
from datatools.newstools import *
from twitterarchiveorg.urlgenerator import *
from webcrawler.sample import __version__


urls = \
[
    "https://stackoverflow.com/questions/48141771/bootstrap-doesnt-affect-typography-when-only-imported-to-some-components-in-ang",
    "https://stackoverflow.com/questions/48141873/add-custom-js-scripts-to-angular-5-mean-index-html-file",
    "https://stackoverflow.com/questions/48140520/why-is-image-not-shown-properly-as-a-button-background-in-kivy",
    "https://stackoverflow.com/questions/45992446/kotlin-build-cannot-get-classes-created-by-squiddatabase",
    "https://stackoverflow.com/questions/48141856/is-subtracting-a-char-by-0-to-convert-to-int-bad-practice",
    "https://stackoverflow.com/questions/48141744/golang-concatination-array-of-int",
    "https://stackoverflow.com/questions/48141844/extraneous-bullet-point-in-unordered-list",
    "https://stackoverflow.com/questions/48141841/what-is-w-c-doing",
    "https://stackoverflow.com/questions/48134404/improving-my-python-solution-for-csv-name-parsing-lastname-firstname-to-firstn",
    "https://stackoverflow.com/questions/45686090/how-to-set-default-bottomnavigationview-tab-in-kotlin",
    "https://stackoverflow.com/questions/48141324/tkinter-entry-box-value-doesnt-store-into-stringvar-object",
    "https://stackoverflow.com/questions/48136732/item-onclick-recyclerview-kotllin-android",
    "https://stackoverflow.com/questions/46943128/failing-to-run-unit-tests-on-a-new-android-kotlin-project",
    "https://stackoverflow.com/questions/48141826/angular-signalr-hubconnection-gives-protocol-error-unknown-transport",
    "https://stackoverflow.com/questions/47213006/databinding-error-in-android-spinner",
    "https://stackoverflow.com/questions/48141731/i-changed-python-exe-to-python3-exe-but-now-pip-returns-an-error-how-can-i",
]

loggerFailed = Logger("proxies-failed.log")
logger = Logger("proxies-ok.log")

log("STARTING...", logger)

proxiesFailed = ""

for proxiesPath in \
[
    dataDir() + "/Misc/crawling/proxies-renew.txt",
    dataDir() + "/Misc/crawling/proxies-linkedin.txt",
]:
    log(proxiesPath, loggerFailed)
    log(proxiesPath, logger)
    proxies = getProxies(proxiesPath)
    for proxy in proxies:
        b = Browser(proxy=proxy, driverType=DRIVER_TYPE.phantomjs, verbose=False, ajaxSleep=0.5)
        url1 = random.choice(urls)
        url2 = random.choice(urls)
        result1 = b.html(url1)
        result2 = b.html(url1)
        if result1["status"] == result2["status"] == REQUEST_STATUS.refused:
            log(proxy["ip"] + " FAILED", loggerFailed)
            proxiesFailed += proxy["ip"] + ":" + proxy["port"] + ":" + proxy["user"] + ":" + proxy["password"] + "\n"
        else:
            log(proxy["ip"] + " OK: " + str(result1["status"]) + " " + str(result2["status"]), logger)

strToFile(proxiesFailed, dataDir() + "/Misc/crawling/proxies-failed.txt")

log("END!", logger)

